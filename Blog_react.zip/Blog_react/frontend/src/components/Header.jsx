import React from "react";

const Header = () => {
  return (
    <div>
      <div className="container-fluid text-center"   >
  <h1 style={{
      backgroundColor: '#5F9EA0', 
      padding: '2rem',
      textAlign: 'center',
      

      color: 'black'
    }}>
    Welcome to Blog App
  </h1>
</div>

    </div>
  );
};

export default Header;
