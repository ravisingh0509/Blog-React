import React from "react";

const Footer = () => {
  return (
    <footer
    className="text-center p-3"
    style={{ backgroundColor: '#708090', color: 'black' }} 
  >
    <div className="container-fluid">
      copyright &copy; reserved by Blog App
    </div>
  </footer>
  
  );
};

export default Footer;
